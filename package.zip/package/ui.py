"""
ui.py
------
Professional OpenCV user interface.
"""

import cv2
from .utils import draw_text_background


# -------------------------------
# Color Palette
# -------------------------------

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

GREEN = (0, 255, 0)
RED = (0, 0, 255)
BLUE = (255, 170, 0)

DARK_GRAY = (40, 40, 40)
LIGHT_GRAY = (80, 80, 80)


# -------------------------------
# Header
# -------------------------------

def draw_header(image, title, face_count):

    height, width = image.shape[:2]

    cv2.rectangle(
        image,
        (0, 0),
        (width, 50),
        DARK_GRAY,
        -1
    )

    cv2.putText(
        image,
        title,
        (15, 22),
        cv2.FONT_HERSHEY_DUPLEX,
        0.65,
        WHITE,
        2,
        cv2.LINE_AA
    )

    cv2.putText(
        image,
        f"Faces Detected : {face_count}",
        (15, 43),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        GREEN,
        2,
        cv2.LINE_AA
    )


# -------------------------------
# Footer
# -------------------------------

def draw_footer(image):

    height, width = image.shape[:2]

    cv2.rectangle(
        image,
        (0, height - 30),
        (width, height),
        DARK_GRAY,
        -1
    )

    cv2.putText(
        image,
        "Press Q to Quit | Any Other Key = Next Image",
        (10, height - 10),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        WHITE,
        1,
        cv2.LINE_AA
    )


# -------------------------------
# Face Bounding Box
# -------------------------------

def draw_face_box(image, x, y, w, h):

    cv2.rectangle(
        image,
        (x, y),
        (x + w, y + h),
        GREEN,
        2
    )

    # Corner accents

    corner = 18
    thickness = 3

    # Top Left
    cv2.line(image, (x, y), (x + corner, y), GREEN, thickness)
    cv2.line(image, (x, y), (x, y + corner), GREEN, thickness)

    # Top Right
    cv2.line(image, (x + w, y), (x + w - corner, y), GREEN, thickness)
    cv2.line(image, (x + w, y), (x + w, y + corner), GREEN, thickness)

    # Bottom Left
    cv2.line(image, (x, y + h), (x + corner, y + h), GREEN, thickness)
    cv2.line(image, (x, y + h), (x, y + h - corner), GREEN, thickness)

    # Bottom Right
    cv2.line(image, (x + w, y + h), (x + w - corner, y + h), GREEN, thickness)
    cv2.line(image, (x + w, y + h), (x + w, y + h - corner), GREEN, thickness)


# -------------------------------
# Face Information Card
# -------------------------------

def draw_face_card(image, x, y, face_number, age_label):

    label = f"Face #{face_number} | {age_label}"

    (tw, th), _ = cv2.getTextSize(
        label,
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        2
    )

    padding = 8

    card_x = x
    card_y = y - th - 18

    if card_y < 55:
        card_y = y + 30

    if card_x + tw + 20 > image.shape[1]:
        card_x = image.shape[1] - tw - 20

    draw_text_background(
        image=image,
        text=label,
        position=(card_x + padding, card_y + th),
        font_scale=0.55,
        background_color=BLUE,
        text_color=WHITE,
        thickness=2,
    )


# -------------------------------
# Complete Face Drawing
# -------------------------------

def draw_face(image, x, y, w, h, face_number, age_label):

    draw_face_box(
        image,
        x,
        y,
        w,
        h
    )

    draw_face_card(
        image,
        x,
        y,
        face_number,
        age_label
    )
